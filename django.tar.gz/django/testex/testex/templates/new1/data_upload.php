<?php   
    print "Path to the data that you entered  ". $path;   
    print "<br />";   
    print "You selected server  ". $Server;   
    print "<br />";   
       
?>
